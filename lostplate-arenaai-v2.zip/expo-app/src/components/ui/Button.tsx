import React from 'react';
import { Pressable, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { colors, radius, typography } from '../../constants/theme';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  style?: ViewStyle;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export const Button: React.FC<ButtonProps> = ({ label, onPress, variant = 'primary', style }) => {
  const scale = useSharedValue(1);

  const handlePressIn = () => {
    // Fast spring: tension 400, friction 30
    scale.value = withSpring(0.97, { stiffness: 400, damping: 30 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { stiffness: 400, damping: 30 });
  };

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: scale.value }]
    };
  });

  const getContainerStyles = (): ViewStyle => {
    switch (variant) {
      case 'secondary':
        return { backgroundColor: colors.neutral50, borderColor: colors.neutral200, borderWidth: 1 };
      case 'outline':
        return { backgroundColor: 'transparent', borderColor: colors.blue400, borderWidth: 1 };
      default:
        return { backgroundColor: colors.blue400 };
    }
  };

  const getTextStyles = (): TextStyle => {
    switch (variant) {
      case 'secondary':
        return { color: colors.neutral600 };
      case 'outline':
        return { color: colors.blue400 };
      default:
        return { color: colors.white };
    }
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[styles.container, getContainerStyles(), animatedStyle, style]}
    >
      <Text style={[styles.text, getTextStyles()]}>{label}</Text>
    </AnimatedPressable>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 56,
    width: '100%',
    borderRadius: radius.button,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontFamily: typography.fonts.semiBold,
    fontSize: 16,
    letterSpacing: 0.1,
  }
});

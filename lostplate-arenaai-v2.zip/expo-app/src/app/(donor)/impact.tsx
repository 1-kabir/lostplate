import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView } from 'react-native';
import { colors, typography, spacing, radius } from '../../constants/theme';
import { Button } from '../../components/ui/Button';

export default function DonorImpactScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.pageTitle}>FoodPrint™</Text>
        
        <View style={styles.heroSection}>
          <Text style={styles.heroLabel}>Total Rescued</Text>
          <Text style={styles.heroNumber}>124<Text style={styles.heroUnit}> kg</Text></Text>
        </View>

        <View style={styles.grid}>
          <View style={styles.gridItem}>
            <Text style={styles.gridLabel}>Meals Enabled</Text>
            <Text style={styles.gridValue}>372</Text>
          </View>
          <View style={styles.gridItem}>
            <Text style={styles.gridLabel}>CO₂ Saved</Text>
            <Text style={styles.gridValue}>310 kg</Text>
          </View>
          <View style={styles.gridItem}>
            <Text style={styles.gridLabel}>Water Saved</Text>
            <Text style={styles.gridValue}>124k L</Text>
          </View>
          <View style={styles.gridItem}>
            <Text style={styles.gridLabel}>Days Active</Text>
            <Text style={styles.gridValue}>42</Text>
          </View>
        </View>

        <View style={{ marginTop: spacing.s40 }}>
          <Button variant="outline" label="Share Milestone" onPress={() => {}} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral0,
  },
  content: {
    padding: spacing.screenHorizontal,
    paddingTop: 40,
  },
  pageTitle: {
    fontFamily: typography.fonts.bold,
    fontSize: typography.size.xl.fontSize,
    color: colors.neutral900,
    marginBottom: spacing.s32,
    textAlign: 'center',
  },
  heroSection: {
    alignItems: 'center',
    marginBottom: spacing.s40,
  },
  heroLabel: {
    fontFamily: typography.fonts.semiBold,
    fontSize: typography.size.md.fontSize,
    color: colors.neutral600,
    marginBottom: 8,
  },
  heroNumber: {
    fontFamily: typography.fonts.extraBold,
    fontSize: typography.size.xxxl.fontSize,
    color: colors.blue500,
    letterSpacing: -1,
    lineHeight: typography.size.xxxl.lineHeight,
  },
  heroUnit: {
    fontSize: typography.size.xxl.fontSize,
    color: colors.blue400,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  gridItem: {
    width: '47%',
    backgroundColor: colors.blue50,
    padding: 20,
    borderRadius: radius.card,
    borderWidth: 1,
    borderColor: colors.blue100,
  },
  gridLabel: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.sm.fontSize,
    color: colors.neutral600,
    marginBottom: 8,
  },
  gridValue: {
    fontFamily: typography.fonts.bold,
    fontSize: typography.size.lg.fontSize,
    color: colors.blue600,
  }
});

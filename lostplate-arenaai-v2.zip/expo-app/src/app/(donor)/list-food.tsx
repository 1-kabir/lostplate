import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, TextInput, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { useListingStore } from '../../store/listingStore';
import { useAuthStore } from '../../store/authStore';
import { colors, typography, spacing, radius } from '../../constants/theme';
import { Button } from '../../components/ui/Button';
import { CaretLeft } from 'phosphor-react-native';

const CATEGORIES = ['Cooked Meals', 'Raw Produce', 'Packaged Goods', 'Beverages', 'Bakery'];
const EXPIRY = ['Now', 'Within 2h', 'Within 6h', 'Today'];

export default function ListFoodScreen() {
  const router = useRouter();
  const { addListing } = useListingStore();
  const { user } = useAuthStore();
  
  const [foodName, setFoodName] = useState('');
  const [category, setCategory] = useState('Cooked Meals');
  const [qty, setQty] = useState('10');
  const [expiry, setExpiry] = useState('Within 2h');

  const handleSubmit = () => {
    if (!foodName) return;
    addListing({
      donorName: user?.name || 'Unknown',
      foodName,
      category,
      qty: parseInt(qty) || 0,
      urgency: expiry === 'Now' || expiry === 'Within 2h' ? 'red' : expiry === 'Within 6h' ? 'amber' : 'green',
      status: 'available',
      distance: '0.0 km',
      timeRemaining: expiry
    });
    router.back();
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <CaretLeft color={colors.neutral900} size={24} />
        </Pressable>
        <Text style={styles.headerTitle}>List Food</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.label}>What are you donating?</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. 2 trays of Chicken Biryani"
          placeholderTextColor={colors.neutral400}
          value={foodName}
          onChangeText={setFoodName}
        />

        <Text style={styles.label}>Category</Text>
        <View style={styles.chipsContainer}>
          {CATEGORIES.map(cat => (
            <Pressable
              key={cat}
              style={[styles.chip, category === cat && styles.chipActive]}
              onPress={() => setCategory(cat)}
            >
              <Text style={[styles.chipText, category === cat && styles.chipTextActive]}>{cat}</Text>
            </Pressable>
          ))}
        </View>

        <Text style={styles.label}>Quantity (kg)</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. 10"
          placeholderTextColor={colors.neutral400}
          keyboardType="numeric"
          value={qty}
          onChangeText={setQty}
        />

        <Text style={styles.label}>When does it expire?</Text>
        <View style={styles.chipsContainer}>
          {EXPIRY.map(exp => (
            <Pressable
              key={exp}
              style={[styles.chip, expiry === exp && styles.chipActive]}
              onPress={() => setExpiry(exp)}
            >
              <Text style={[styles.chipText, expiry === exp && styles.chipTextActive]}>{exp}</Text>
            </Pressable>
          ))}
        </View>

        <View style={{ marginTop: spacing.s40 }}>
          <Button label="Publish Listing" onPress={handleSubmit} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral0,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.screenHorizontal,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral100,
  },
  backBtn: {
    padding: 8,
    marginLeft: -8,
  },
  headerTitle: {
    fontFamily: typography.fonts.bold,
    fontSize: typography.size.md.fontSize,
    color: colors.neutral900,
  },
  content: {
    padding: spacing.screenHorizontal,
    paddingBottom: 40,
  },
  label: {
    fontFamily: typography.fonts.semiBold,
    fontSize: typography.size.base.fontSize,
    color: colors.neutral900,
    marginTop: spacing.s24,
    marginBottom: spacing.s12,
  },
  input: {
    backgroundColor: colors.neutral50,
    borderWidth: 1,
    borderColor: colors.neutral200,
    borderRadius: radius.input,
    height: 56,
    paddingHorizontal: 16,
    fontFamily: typography.fonts.regular,
    fontSize: 15,
    color: colors.neutral900,
  },
  chipsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: radius.pill,
    backgroundColor: colors.neutral50,
    borderWidth: 1,
    borderColor: colors.neutral200,
  },
  chipActive: {
    backgroundColor: colors.blue400,
    borderColor: colors.blue400,
  },
  chipText: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.sm.fontSize,
    color: colors.neutral600,
  },
  chipTextActive: {
    color: colors.white,
  }
});

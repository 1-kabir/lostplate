import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, Pressable } from 'react-native';
import { useAuthStore } from '../../store/authStore';
import { useListingStore } from '../../store/listingStore';
import { colors, typography, spacing, radius, shadows } from '../../constants/theme';
import { FoodCard } from '../../components/FoodCard';
import { useRouter } from 'expo-router';
import { Plus, UserCircle } from 'phosphor-react-native';

export default function DonorDashboard() {
  const { user } = useAuthStore();
  const { listings } = useListingStore();
  const router = useRouter();
  
  const myDonations = listings.filter(l => l.donorName === user?.name || l.status === 'claimed');

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.s24 }}>
          <Text style={styles.greeting}>{user?.name}</Text>
          <Pressable onPress={() => router.push('/(donor)/profile')}>
            <UserCircle color={colors.neutral600} size={28} weight="regular" />
          </Pressable>
        </View>
        
        <View style={styles.heroCard}>
          <Text style={styles.heroLabel}>You've saved</Text>
          <Text style={styles.heroNumber}>45<Text style={styles.heroUnit}> meals</Text></Text>
          <Text style={styles.heroSubtext}>this month</Text>
        </View>

        <Text style={styles.sectionTitle}>Active Listings</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalScroll}>
          {myDonations.map(listing => (
            <View key={listing.id} style={{ width: 280, marginRight: 16 }}>
              <FoodCard listing={listing} />
            </View>
          ))}
        </ScrollView>
      </ScrollView>

      <Pressable style={styles.fab} onPress={() => router.push('/(donor)/list-food')}>
        <Plus color={colors.white} size={24} weight="bold" />
      </Pressable>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral0,
  },
  content: {
    padding: spacing.screenHorizontal,
  },
  greeting: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.lg.fontSize,
    color: colors.neutral600,
  },
  heroCard: {
    backgroundColor: colors.blue100,
    borderRadius: radius.card,
    padding: 24,
    marginBottom: spacing.s32,
  },
  heroLabel: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.md.fontSize,
    color: colors.neutral600,
    marginBottom: 4,
  },
  heroNumber: {
    fontFamily: typography.fonts.extraBold,
    fontSize: typography.size.xxxl.fontSize,
    color: colors.blue500,
    letterSpacing: -1,
  },
  heroUnit: {
    fontSize: typography.size.xl.fontSize,
  },
  heroSubtext: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.sm.fontSize,
    color: colors.neutral600,
    marginTop: 4,
  },
  sectionTitle: {
    fontFamily: typography.fonts.semiBold,
    fontSize: typography.size.lg.fontSize,
    color: colors.neutral900,
    marginBottom: spacing.s20,
  },
  horizontalScroll: {
    paddingBottom: 8,
  },
  fab: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    width: 64,
    height: 64,
    borderRadius: radius.fab,
    backgroundColor: colors.blue400,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.float,
  }
});

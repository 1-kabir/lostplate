import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, TextInput, ScrollView } from 'react-native';
import { useAuthStore } from '../../store/authStore';
import { colors, typography, spacing, radius } from '../../constants/theme';
import { Button } from '../../components/ui/Button';

export default function DonorOnboardScreen() {
  const { setOnboarded } = useAuthStore();
  const [name, setName] = useState('');
  
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.progressBar} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>What's the name of your business?</Text>
        
        <View style={styles.form}>
          <TextInput
            style={styles.input}
            placeholder="e.g. Local Cafe"
            placeholderTextColor={colors.neutral400}
            value={name}
            onChangeText={setName}
          />
        </View>
        
        <View style={{ marginTop: spacing.s40 }}>
          <Button label="Complete Setup" onPress={setOnboarded} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral0,
  },
  progressBar: {
    height: 2,
    backgroundColor: colors.blue400,
    width: '33%',
  },
  content: {
    paddingHorizontal: spacing.screenHorizontal,
    paddingTop: 40,
  },
  title: {
    fontFamily: typography.fonts.bold,
    fontSize: typography.size.xl.fontSize,
    color: colors.neutral900,
    lineHeight: typography.size.xl.lineHeight,
    marginBottom: spacing.s32,
    letterSpacing: -0.5,
  },
  form: {
    gap: 16,
  },
  input: {
    backgroundColor: colors.neutral50,
    borderWidth: 1,
    borderColor: colors.neutral200,
    borderRadius: radius.input,
    height: 56,
    paddingHorizontal: 16,
    fontFamily: typography.fonts.regular,
    fontSize: 15,
    color: colors.neutral900,
  }
});

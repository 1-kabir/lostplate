import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, Pressable, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuthStore } from '../../store/authStore';
import { colors, typography, spacing, radius } from '../../constants/theme';
import { Button } from '../../components/ui/Button';

export default function LoginScreen() {
  const [selectedType, setSelectedType] = useState<'donor' | 'ngo'>('donor');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuthStore();

  const handleLogin = () => {
    login(selectedType);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.toggleContainer}>
          <Pressable
            style={[styles.toggleBtn, selectedType === 'donor' && styles.toggleActive]}
            onPress={() => setSelectedType('donor')}
          >
            <Text style={[styles.toggleText, selectedType === 'donor' && styles.toggleTextActive]}>I'm a Donor</Text>
          </Pressable>
          <Pressable
            style={[styles.toggleBtn, selectedType === 'ngo' && styles.toggleActive]}
            onPress={() => setSelectedType('ngo')}
          >
            <Text style={[styles.toggleText, selectedType === 'ngo' && styles.toggleTextActive]}>I'm an NGO</Text>
          </Pressable>
        </View>

        <View style={styles.form}>
          <Text style={styles.label}>Email Address</Text>
          <TextInput
            style={styles.input}
            placeholder="you@example.com"
            placeholderTextColor={colors.neutral400}
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <Text style={styles.label}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="••••••••"
            placeholderTextColor={colors.neutral400}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <View style={{ marginTop: spacing.s24 }}>
            <Button label="Continue" onPress={handleLogin} />
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral0,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.screenHorizontal,
    paddingTop: 60,
  },
  toggleContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 40,
  },
  toggleBtn: {
    flex: 1,
    height: 64,
    backgroundColor: colors.neutral50,
    borderRadius: radius.card,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.neutral100,
  },
  toggleActive: {
    backgroundColor: colors.blue400,
    borderColor: colors.blue400,
  },
  toggleText: {
    fontFamily: typography.fonts.semiBold,
    fontSize: 16,
    color: colors.neutral600,
  },
  toggleTextActive: {
    color: colors.white,
  },
  form: {
    gap: 16,
  },
  label: {
    fontFamily: typography.fonts.medium,
    fontSize: 15,
    color: colors.neutral900,
    marginBottom: -8,
  },
  input: {
    backgroundColor: colors.neutral50,
    borderWidth: 1,
    borderColor: colors.neutral200,
    borderRadius: radius.input,
    height: 56,
    paddingHorizontal: 16,
    fontFamily: typography.fonts.regular,
    fontSize: 15,
    color: colors.neutral900,
  }
});

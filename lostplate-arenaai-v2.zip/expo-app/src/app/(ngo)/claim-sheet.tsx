import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, Pressable, TextInput } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useListingStore } from '../../store/listingStore';
import { colors, typography, spacing, radius, shadows } from '../../constants/theme';
import { Button } from '../../components/ui/Button';
import { CaretLeft } from 'phosphor-react-native';

export default function ClaimSheetScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { listings, claimListing } = useListingStore();
  
  const listing = listings.find(l => l.id === id);
  const [claimQty, setClaimQty] = useState(listing ? listing.qty.toString() : '0');

  if (!listing) return null;

  const handleClaim = () => {
    claimListing(listing.id);
    router.back();
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <CaretLeft color={colors.neutral900} size={24} />
        </Pressable>
        <Text style={styles.headerTitle}>Claim Food</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.content}>
        <View style={styles.summaryCard}>
          <Text style={styles.foodName}>{listing.foodName}</Text>
          <Text style={styles.donorName}>from {listing.donorName}</Text>
          <Text style={styles.qtyAvailable}>{listing.qty} kg available</Text>
        </View>

        <Text style={styles.label}>How much do you need? (kg)</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={claimQty}
          onChangeText={setClaimQty}
        />

        <Text style={styles.label}>Estimated Pickup Time</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. 4:00 PM"
          placeholderTextColor={colors.neutral400}
        />

        <View style={styles.spacer} />

        <Button label={`Confirm Claim (${claimQty} kg)`} onPress={handleClaim} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral0,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.screenHorizontal,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral100,
  },
  backBtn: {
    padding: 8,
    marginLeft: -8,
  },
  headerTitle: {
    fontFamily: typography.fonts.bold,
    fontSize: typography.size.md.fontSize,
    color: colors.neutral900,
  },
  content: {
    flex: 1,
    padding: spacing.screenHorizontal,
  },
  summaryCard: {
    backgroundColor: colors.blue50,
    borderRadius: radius.card,
    padding: 20,
    marginBottom: spacing.s32,
    borderWidth: 1,
    borderColor: colors.blue100,
  },
  foodName: {
    fontFamily: typography.fonts.bold,
    fontSize: typography.size.lg.fontSize,
    color: colors.neutral900,
    marginBottom: 4,
  },
  donorName: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.base.fontSize,
    color: colors.neutral600,
    marginBottom: 12,
  },
  qtyAvailable: {
    fontFamily: typography.fonts.semiBold,
    fontSize: typography.size.md.fontSize,
    color: colors.blue500,
  },
  label: {
    fontFamily: typography.fonts.semiBold,
    fontSize: typography.size.base.fontSize,
    color: colors.neutral900,
    marginBottom: spacing.s12,
  },
  input: {
    backgroundColor: colors.neutral50,
    borderWidth: 1,
    borderColor: colors.neutral200,
    borderRadius: radius.input,
    height: 56,
    paddingHorizontal: 16,
    fontFamily: typography.fonts.regular,
    fontSize: 15,
    color: colors.neutral900,
    marginBottom: spacing.s24,
  },
  spacer: {
    flex: 1,
  }
});

import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, Pressable } from 'react-native';
import { useAuthStore } from '../../store/authStore';
import { useListingStore } from '../../store/listingStore';
import { colors, typography, spacing, radius } from '../../constants/theme';
import { FoodCard } from '../../components/FoodCard';
import { useRouter } from 'expo-router';
import { BellRinging, UserCircle } from 'phosphor-react-native';

export default function NGODashboard() {
  const { user } = useAuthStore();
  const { listings } = useListingStore();
  const router = useRouter();
  
  const availableFood = listings.filter(l => l.status === 'available');

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.greeting}>{user?.name}</Text>
          <View style={{ flexDirection: 'row', gap: 16 }}>
            <Pressable onPress={() => router.push('/(ngo)/profile')}>
              <UserCircle color={colors.neutral600} size={24} weight="regular" />
            </Pressable>
            <BellRinging color={colors.neutral600} size={24} weight="regular" />
          </View>
        </View>

        <View style={styles.banner}>
          <Text style={styles.bannerText}>
            <Text style={{ fontFamily: typography.fonts.bold }}>{availableFood.length}</Text> new donations near you
          </Text>
        </View>

        <View style={styles.statStrip}>
          <View style={[styles.statBox, { flex: 2 }]}>
            <Text style={styles.statLabel}>Total Collected</Text>
            <Text style={styles.statValue}>124 kg</Text>
          </View>
          <View style={[styles.statBox, { flex: 1.5 }]}>
            <Text style={styles.statLabel}>Meals</Text>
            <Text style={styles.statValue}>372</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Urgent Available</Text>
        <View style={styles.list}>
          {availableFood.map(listing => (
            <FoodCard key={listing.id} listing={listing} />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral0,
  },
  content: {
    padding: spacing.screenHorizontal,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.s24,
  },
  greeting: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.lg.fontSize,
    color: colors.neutral600,
  },
  banner: {
    backgroundColor: colors.blue50,
    borderWidth: 1,
    borderColor: colors.blue200,
    borderRadius: radius.card,
    padding: 16,
    marginBottom: spacing.s24,
  },
  bannerText: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.md.fontSize,
    color: colors.blue600,
  },
  statStrip: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: spacing.s32,
  },
  statBox: {
    backgroundColor: colors.blue100,
    padding: 16,
    borderRadius: radius.card,
  },
  statLabel: {
    fontFamily: typography.fonts.medium,
    fontSize: typography.size.sm.fontSize,
    color: colors.neutral600,
    marginBottom: 4,
  },
  statValue: {
    fontFamily: typography.fonts.bold,
    fontSize: typography.size.xl.fontSize,
    color: colors.blue500,
  },
  sectionTitle: {
    fontFamily: typography.fonts.semiBold,
    fontSize: typography.size.lg.fontSize,
    color: colors.neutral900,
    marginBottom: spacing.s20,
  },
  list: {
    gap: 16,
  }
});

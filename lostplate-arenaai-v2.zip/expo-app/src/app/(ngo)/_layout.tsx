import { Tabs } from 'expo-router';
import { House, MagnifyingGlass, MapPin, ChartBar, Calendar } from 'phosphor-react-native';
import { colors, typography } from '../../constants/theme';

export default function NGOLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.white,
          borderTopWidth: 1,
          borderTopColor: colors.neutral100,
          elevation: 0,
        },
        tabBarActiveTintColor: colors.blue400,
        tabBarInactiveTintColor: colors.neutral400,
        tabBarLabelStyle: {
          fontFamily: typography.fonts.medium,
          fontSize: 11,
        }
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => <House color={color as string} size={24} weight="regular" />
        }}
      />
      <Tabs.Screen
        name="browse"
        options={{
          title: 'Browse',
          tabBarIcon: ({ color, size }) => <MagnifyingGlass color={color as string} size={24} weight="regular" />
        }}
      />
      <Tabs.Screen
        name="map"
        options={{
          title: 'Map',
          tabBarIcon: ({ color, size }) => <MapPin color={color as string} size={24} weight="regular" />
        }}
      />
      <Tabs.Screen
        name="schedule"
        options={{
          title: 'Schedule',
          tabBarIcon: ({ color, size }) => <Calendar color={color as string} size={24} weight="regular" />
        }}
      />
      <Tabs.Screen
        name="impact"
        options={{
          title: 'Impact',
          tabBarIcon: ({ color, size }) => <ChartBar color={color as string} size={24} weight="regular" />
        }}
      />
      <Tabs.Screen
        name="claim-sheet"
        options={{
          href: null,
          tabBarStyle: { display: 'none' },
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          href: null,
          tabBarStyle: { display: 'none' },
        }}
      />
    </Tabs>
  );
}

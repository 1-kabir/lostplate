import { useEffect } from 'react';
import { Slot, useRouter, useSegments } from 'expo-router';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import { useAuthStore } from '../store/authStore';
import {
  PlusJakartaSans_400Regular,
  PlusJakartaSans_500Medium,
  PlusJakartaSans_600SemiBold,
  PlusJakartaSans_700Bold,
  PlusJakartaSans_800ExtraBold,
} from '@expo-google-fonts/plus-jakarta-sans';

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    PlusJakartaSans_400Regular,
    PlusJakartaSans_500Medium,
    PlusJakartaSans_600SemiBold,
    PlusJakartaSans_700Bold,
    PlusJakartaSans_800ExtraBold,
  });

  const { user } = useAuthStore();
  const segments: string[] = useSegments() as any;
  const router = useRouter();

  useEffect(() => {
    if (fontsLoaded) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  useEffect(() => {
    if (!fontsLoaded) return;

    const inAuthGroup = segments[0] === '(auth)';

    if (!user && !inAuthGroup) {
      router.replace('/(auth)');
    } else if (user && user.onboarded) {
      if (inAuthGroup) {
        if (user.type === 'donor') {
          router.replace('/(donor)');
        } else {
          router.replace('/(ngo)');
        }
      }
    } else if (user && !user.onboarded) {
      const seg1 = segments.length > 1 ? segments[1] : '';
      if (user.type === 'donor' && seg1 !== 'donor-onboard') {
        router.replace('/(auth)/donor-onboard');
      } else if (user.type === 'ngo' && seg1 !== 'ngo-onboard') {
        router.replace('/(auth)/ngo-onboard');
      }
    }
  }, [user, segments, fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return <Slot />;
}
